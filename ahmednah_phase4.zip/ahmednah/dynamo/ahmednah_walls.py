# -*- coding: utf-8 -*-
"""
ahmednah - Dynamo Python Script (المرحلة الثانية)
=================================================
يُلصق داخل عقدة Python Script في Dynamo (يعمل على CPython3 و IronPython2).

المدخلات:
    IN[0]  مسار ملف Excel الناتج من ahmednah (ورقة Walls)
    IN[1]  ارتفاع الجدار بالمتر (مثلاً 3.5)
    IN[2]  اسم المستوى (Level) — اتركه فارغاً لاستخدام أدنى مستوى في المشروع

المخرجات (قائمة من 5 عناصر):
    OUT[0] curves      : خطوط محاور الجدران (Dynamo Lines)
    OUT[1] wall_types  : نوع الجدار المناسب لكل خط حسب سماكته
    OUT[2] level       : المستوى
    OUT[3] height      : الارتفاع بوحدات Dynamo
    OUT[4] report      : تقرير نصي

هذه المخرجات تدخل مباشرة إلى عقدة Wall.ByCurveAndHeight في الـ Graph.

ملاحظة: لا نستخدم openpyxl لأنها غير موجودة داخل Dynamo.
ملف xlsx هو ملف zip فيه XML، فنقرؤه بمكتبات بايثون القياسية فقط.
"""

import clr
import re
import zipfile
import xml.etree.ElementTree as ET

clr.AddReference("ProtoGeometry")
from Autodesk.DesignScript.Geometry import Point, Line

clr.AddReference("RevitNodes")
import Revit
clr.ImportExtensions(Revit.Elements)
clr.ImportExtensions(Revit.GeometryConversion)

clr.AddReference("RevitServices")
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

clr.AddReference("RevitAPI")
import Autodesk.Revit.DB as DB

doc = DocumentManager.Instance.CurrentDBDocument
FT_PER_M = 1.0 / 0.3048


# ---------------------------------------------------------------------------
# 1) قراءة ملف Excel بدون مكتبات خارجية
# ---------------------------------------------------------------------------
NS_M = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _col_index(ref):
    letters = re.match(r"([A-Z]+)", ref).group(1)
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def read_xlsx_sheet(path, sheet_name):
    z = zipfile.ZipFile(path)
    names = z.namelist()

    shared = []
    if "xl/sharedStrings.xml" in names:
        root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in root.findall("{%s}si" % NS_M):
            shared.append("".join([t.text or "" for t in si.iter("{%s}t" % NS_M)]))

    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    relmap = dict((r.get("Id"), r.get("Target")) for r in rels)

    target = None
    for sh in wb.find("{%s}sheets" % NS_M):
        if sh.get("name") == sheet_name:
            target = relmap[sh.get("{%s}id" % NS_R)]
    if target is None:
        raise Exception("Sheet '%s' not found in Excel file" % sheet_name)
    target = target[1:] if target.startswith("/") else "xl/" + target

    sheet = ET.fromstring(z.read(target))
    rows = []
    for row in sheet.find("{%s}sheetData" % NS_M):
        cells = {}
        for c in row:
            t = c.get("t")
            if t == "inlineStr":
                v = "".join([x.text or "" for x in c.iter("{%s}t" % NS_M)])
            else:
                v_el = c.find("{%s}v" % NS_M)
                v = v_el.text if v_el is not None else None
                if v is not None:
                    if t == "s":
                        v = shared[int(v)]
                    elif t not in ("str", "b", "e"):
                        v = float(v)
            cells[_col_index(c.get("r"))] = v
        if cells:
            rows.append([cells.get(i) for i in range(max(cells) + 1)])
    z.close()
    return rows


def read_walls(path):
    rows = read_xlsx_sheet(path, "Walls")
    header = [str(h).strip() for h in rows[0]]
    need = ["Wall_ID", "X1", "Y1", "X2", "Y2", "Thickness_m"]
    for n in need:
        if n not in header:
            raise Exception("Missing column '%s' in sheet Walls" % n)
    idx = dict((n, header.index(n)) for n in need)
    walls = []
    for r in rows[1:]:
        try:
            walls.append(dict((n, float(r[idx[n]])) for n in need))
        except (TypeError, ValueError, IndexError):
            continue  # صف فارغ أو ناقص
    return walls


# ---------------------------------------------------------------------------
# 2) الوحدات: كم وحدة Dynamo في المتر؟
#    Dynamo for Revit يقرأ الأرقام بوحدات المشروع (مم/سم/م/قدم)، لذلك نحسبها
# ---------------------------------------------------------------------------
def dynamo_units_per_meter():
    from Revit.GeometryConversion import UnitConverter
    for spec in ("SpecTypeId", "UnitType"):
        try:
            if spec == "SpecTypeId":
                f = UnitConverter.DynamoToHostFactor(DB.SpecTypeId.Length)  # Revit 2021+
            else:
                f = UnitConverter.DynamoToHostFactor(DB.UnitType.UT_Length)  # Revit 2020-
            return FT_PER_M / f
        except Exception:
            pass
    return 1.0  # احتياط: نفترض متر


# ---------------------------------------------------------------------------
# 3) المستوى
# ---------------------------------------------------------------------------
def get_level(name):
    levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level))
    if not levels:
        raise Exception("No levels in this Revit project")
    if name:
        for l in levels:
            if l.Name.strip().lower() == name.strip().lower():
                return l
        raise Exception("Level '%s' not found. Available: %s" % (name, ", ".join([l.Name for l in levels])))
    return sorted(levels, key=lambda l: l.Elevation)[0]


# ---------------------------------------------------------------------------
# 4) نوع الجدار حسب السماكة: نبحث عن نوع موجود، وإلا ننشئ واحداً
# ---------------------------------------------------------------------------
def type_name(t):
    try:
        return t.Name
    except Exception:
        return t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()


def get_or_create_wall_type(width_m, cache, created):
    key = int(round(width_m * 1000))  # بالمليمتر
    if key in cache:
        return cache[key]

    width_ft = width_m * FT_PER_M
    wanted = "ahmednah_%dmm" % key
    basics = [t for t in DB.FilteredElementCollector(doc).OfClass(DB.WallType)
              if t.Kind == DB.WallKind.Basic]

    found = None
    for t in basics:                       # أ) نوع أنشأناه سابقاً بنفس الاسم
        if type_name(t) == wanted:
            found = t
            break
    if found is None:                      # ب) أي نوع موجود بنفس السماكة (±0.5 مم)
        for t in basics:
            if abs(t.Width - width_ft) < 0.5 / 304.8:
                found = t
                break
    if found is None:                      # ج) ننسخ نوعاً بسيطاً ونعدّل سماكته
        def score(t):
            cs = t.GetCompoundStructure()
            layers = cs.LayerCount if cs else 99
            generic = 0 if "generic" in type_name(t).lower() else 1
            return (layers, generic)
        base = sorted(basics, key=score)[0]
        found = base.Duplicate(wanted)
        cs = found.GetCompoundStructure()
        thick_i = max(range(cs.LayerCount), key=lambda i: cs.GetLayerWidth(i))
        new_w = cs.GetLayerWidth(thick_i) + (width_ft - cs.GetWidth())
        if new_w <= 0:
            raise Exception("Cannot make wall type %s from '%s'" % (wanted, type_name(base)))
        cs.SetLayerWidth(thick_i, new_w)
        found.SetCompoundStructure(cs)
        created.append(wanted)

    cache[key] = found
    return found


# ---------------------------------------------------------------------------
# التنفيذ
# ---------------------------------------------------------------------------
path = IN[0]
height_m = float(IN[1]) if IN[1] else 3.5
level_name = IN[2] if len(IN) > 2 and IN[2] else ""

walls = read_walls(path)
k = dynamo_units_per_meter()

TransactionManager.Instance.EnsureInTransaction(doc)
level = get_level(level_name)
cache, created = {}, []
curves, types = [], []
skipped = 0
for w in walls:
    p1 = Point.ByCoordinates(w["X1"] * k, w["Y1"] * k, 0)
    p2 = Point.ByCoordinates(w["X2"] * k, w["Y2"] * k, 0)
    if p1.DistanceTo(p2) < 0.05 * k:       # أقصر من 5 سم: Revit يرفضه
        skipped += 1
        continue
    curves.append(Line.ByStartPointEndPoint(p1, p2))
    types.append(get_or_create_wall_type(w["Thickness_m"], cache, created).ToDSType(True))
TransactionManager.Instance.TransactionTaskDone()

report = "\n".join([
    "ahmednah - walls ready: %d (skipped %d)" % (len(curves), skipped),
    "Level: %s | Height: %.2f m" % (level.Name, height_m),
    "Dynamo units per meter: %g" % k,
    "Wall types used: %s" % ", ".join(sorted(set(type_name(t) for t in cache.values()))),
    "Wall types created: %s" % (", ".join(created) if created else "none"),
])

OUT = [curves, types, level.ToDSType(True), height_m * k, report]
