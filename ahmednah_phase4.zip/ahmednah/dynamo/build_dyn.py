"""
يبني ملف ahmednah_walls.dyn من ahmednah_walls.py
(إذا عدّلت كود بايثون، شغّل هذا السكربت لتحديث ملف Dynamo)

    python dynamo/build_dyn.py
"""

import json
import uuid
from pathlib import Path

HERE = Path(__file__).parent


def gid():
    return uuid.uuid4().hex


def port(name, desc=""):
    return {"Id": gid(), "Name": name, "Description": desc, "UsingDefaultValue": False,
            "Level": 2, "UseLevels": False, "KeepListStructure": False}


def node(concrete, node_type, inputs, outputs, desc="", replication="Disabled", **extra):
    n = {"ConcreteType": concrete, "NodeType": node_type, "Id": gid(), "Inputs": inputs,
         "Outputs": outputs, "Replication": replication, "Description": desc}
    n.update(extra)
    return n


def build():
    code = (HERE / "ahmednah_walls.py").read_text(encoding="utf-8")

    n_file = node("CoreNodeModels.Input.Filename, CoreNodeModels", "ExtensionNode", [],
                  [port("", "File path")], "Excel file from ahmednah", HintPath="", InputValue="")
    n_h = node("CoreNodeModels.Input.DoubleInput, CoreNodeModels", "NumberInputNode", [],
               [port("", "Double")], "Wall height (m)", NumberType="Double", InputValue=3.5)
    n_lvl = node("CoreNodeModels.Input.StringInput, CoreNodeModels", "StringInputNode", [],
                 [port("", "String")], "Level name (empty = lowest)", InputValue="")
    n_py = node("PythonNodeModels.PythonNode, PythonNodeModels", "PythonScriptNode",
                [port("IN[0]", "Excel path"), port("IN[1]", "Height m"), port("IN[2]", "Level name")],
                [port("OUT", "Result of the python script")], "ahmednah: read Excel walls",
                Code=code, Engine="CPython3", EngineName="CPython3", VariableInputPorts=True)
    n_cb = node("Dynamo.Graph.Nodes.CodeBlockNodeModel, DynamoCore", "CodeBlockNode",
                [port("o")], [port("", "curves"), port("", "wall types"), port("", "level"),
                              port("", "height"), port("", "report")], "Split outputs",
                Code="o[0];\no[1];\no[2];\no[3];\no[4];")
    n_wall = node("Dynamo.Graph.Nodes.ZeroTouch.DSFunction, DynamoCore", "FunctionNode",
                  [port("curve", "Curve"), port("height", "double"), port("level", "Level"),
                   port("wallType", "WallType")], [port("Wall", "Wall")],
                  "Create walls", replication="Auto",
                  FunctionSignature="Revit.Elements.Wall.ByCurveAndHeight@Autodesk.DesignScript."
                                    "Geometry.Curve,double,Revit.Elements.Level,Revit.Elements.WallType")
    n_watch = node("CoreNodeModels.Watch, CoreNodeModels", "ExtensionNode",
                   [port("", "Node to show output from")], [port("", "Node output")], "Report")
    n_watch2 = node("CoreNodeModels.Watch, CoreNodeModels", "ExtensionNode",
                    [port("", "Node to show output from")], [port("", "Node output")], "Walls")

    # ---- المرحلة 3: الأبواب والشبابيك
    code2 = (HERE / "ahmednah_openings.py").read_text(encoding="utf-8")
    n_door = node("CoreNodeModels.Input.StringInput, CoreNodeModels", "StringInputNode", [],
                  [port("", "String")], "Door family/type (optional)", InputValue="")
    n_win = node("CoreNodeModels.Input.StringInput, CoreNodeModels", "StringInputNode", [],
                 [port("", "String")], "Window family/type (optional)", InputValue="")
    n_sill = node("CoreNodeModels.Input.DoubleInput, CoreNodeModels", "NumberInputNode", [],
                  [port("", "Double")], "Window sill height (m)", NumberType="Double", InputValue=0.9)
    n_oh = node("CoreNodeModels.Input.DoubleInput, CoreNodeModels", "NumberInputNode", [],
                [port("", "Double")], "Empty opening height (m)", NumberType="Double", InputValue=2.1)
    n_py2 = node("PythonNodeModels.PythonNode, PythonNodeModels", "PythonScriptNode",
                 [port("IN[0]", "Walls"), port("IN[1]", "Excel path"), port("IN[2]", "Door type"),
                  port("IN[3]", "Window type"), port("IN[4]", "Sill m"), port("IN[5]", "Opening h m")],
                 [port("OUT", "Result of the python script")], "ahmednah: doors & windows",
                 Code=code2, Engine="CPython3", EngineName="CPython3", VariableInputPorts=True)
    n_cb2 = node("Dynamo.Graph.Nodes.CodeBlockNodeModel, DynamoCore", "CodeBlockNode",
                 [port("p")], [port("", "instances"), port("", "report")], "Split", Code="p[0];\np[1];")
    n_watch3 = node("CoreNodeModels.Watch, CoreNodeModels", "ExtensionNode",
                    [port("", "Node to show output from")], [port("", "Node output")], "Openings report")
    n_watch4 = node("CoreNodeModels.Watch, CoreNodeModels", "ExtensionNode",
                    [port("", "Node to show output from")], [port("", "Node output")], "Doors & windows")

    nodes = [n_file, n_h, n_lvl, n_py, n_cb, n_wall, n_watch, n_watch2,
             n_door, n_win, n_sill, n_oh, n_py2, n_cb2, n_watch3, n_watch4]

    def link(a, ai, b, bi):
        return {"Start": a["Outputs"][ai]["Id"], "End": b["Inputs"][bi]["Id"], "Id": gid(),
                "IsHidden": "False"}

    connectors = [
        link(n_file, 0, n_py, 0), link(n_h, 0, n_py, 1), link(n_lvl, 0, n_py, 2),
        link(n_py, 0, n_cb, 0),
        link(n_cb, 0, n_wall, 0), link(n_cb, 3, n_wall, 1), link(n_cb, 2, n_wall, 2),
        link(n_cb, 1, n_wall, 3),
        link(n_cb, 4, n_watch, 0), link(n_wall, 0, n_watch2, 0),
        link(n_wall, 0, n_py2, 0), link(n_file, 0, n_py2, 1), link(n_door, 0, n_py2, 2),
        link(n_win, 0, n_py2, 3), link(n_sill, 0, n_py2, 4), link(n_oh, 0, n_py2, 5),
        link(n_py2, 0, n_cb2, 0), link(n_cb2, 1, n_watch3, 0), link(n_cb2, 0, n_watch4, 0),
    ]

    views = []
    layout = {  # الاسم والموقع على اللوحة
        n_file["Id"]: ("1. Excel File (ahmednah)", 0, 0),
        n_h["Id"]: ("2. Wall Height (m)", 0, 160),
        n_lvl["Id"]: ("3. Level Name (empty = lowest)", 0, 300),
        n_py["Id"]: ("ahmednah - Read Walls", 420, 120),
        n_cb["Id"]: ("Split", 720, 120),
        n_wall["Id"]: ("Wall.ByCurveAndHeight", 1000, 80),
        n_watch["Id"]: ("Report", 1000, 380),
        n_watch2["Id"]: ("Walls", 1380, 80),
        n_door["Id"]: ("4. Door Type (empty = any)", 1000, 620),
        n_win["Id"]: ("5. Window Type (empty = any)", 1000, 740),
        n_sill["Id"]: ("6. Window Sill Height (m)", 1000, 860),
        n_oh["Id"]: ("7. Empty Opening Height (m)", 1000, 980),
        n_py2["Id"]: ("ahmednah - Doors & Windows", 1420, 640),
        n_cb2["Id"]: ("Split", 1720, 640),
        n_watch3["Id"]: ("Openings Report", 1950, 760),
        n_watch4["Id"]: ("Doors & Windows", 1950, 560),
    }
    for n in nodes:
        name, x, y = layout[n["Id"]]
        views.append({"Id": n["Id"], "Name": name, "IsSetAsInput": n in (n_file, n_h, n_lvl, n_door, n_win, n_sill, n_oh),
                      "IsSetAsOutput": False, "Excluded": False, "ShowGeometry": True, "X": x, "Y": y})

    graph = {
        "Uuid": str(uuid.uuid4()), "IsCustomNode": False,
        "Description": "ahmednah - walls, doors and windows from Excel",
        "Name": "ahmednah_walls", "ElementResolver": {"ResolutionMap": {}},
        "Inputs": [], "Outputs": [], "Nodes": nodes, "Connectors": connectors,
        "Dependencies": [], "NodeLibraryDependencies": [], "Bindings": [],
        "View": {
            "Dynamo": {"ScaleFactor": 1.0, "HasRunWithoutCrash": True, "IsVisibleInDynamoLibrary": True,
                       "Version": "2.13.1.3887", "RunType": "Manual", "RunPeriod": "1000"},
            "Camera": {"Name": "Background Preview", "EyeX": -17.0, "EyeY": 24.0, "EyeZ": 50.0,
                       "LookX": 12.0, "LookY": -13.0, "LookZ": -58.0, "UpX": 0.0, "UpY": 1.0, "UpZ": 0.0},
            "NodeViews": views, "Annotations": [], "X": 40.0, "Y": 60.0, "Zoom": 0.8,
        },
    }
    out = HERE / "ahmednah_walls.dyn"
    out.write_text(json.dumps(graph, indent=2, ensure_ascii=False), encoding="utf-8")
    print("تم إنشاء:", out)


if __name__ == "__main__":
    build()
