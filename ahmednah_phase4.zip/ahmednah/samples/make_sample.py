"""
يولّد مخططاً تجريبياً (sample_plan.pdf) لاختبار التطبيق إن لم يكن لديك ملف AutoCAD.
- غرفتان، جدران خارجية 25 سم، جدار داخلي 15 سم
- شباك في الجدار الجنوبي (خطا الوجهين + خط زجاج في المنتصف)
- باب مدخل في الجدار الجنوبي، وباب داخلي، كلاهما بقوس فتح
المقياس 1:100.   التشغيل:  python samples/make_sample.py
"""

from pathlib import Path

import pymupdf

SCALE = 100
M = 1000 / SCALE / (25.4 / 72)  # كم point في المتر على مقياس 1:100
KAPPA = 0.5523                   # لتقريب ربع دائرة بمنحنى بيزيه


def main():
    doc = pymupdf.open()
    page = doc.new_page(width=842, height=595)  # A4 أفقي
    H = page.rect.height
    sh = page.new_shape()

    def P(x, y):  # متر (Y للأعلى) → PDF point (Y للأسفل)
        return pymupdf.Point(40 + x * M, H - 40 - y * M)

    def line(x1, y1, x2, y2):
        sh.draw_line(P(x1, y1), P(x2, y2))

    def door_swing(hx, hy, ux, uy, nx, ny, r):
        """مفصلة عند (hx,hy)، u: اتجاه الفتحة على طول الجدار، n: جهة الفتح."""
        tip = (hx + nx * r, hy + ny * r)
        latch = (hx + ux * r, hy + uy * r)
        line(hx, hy, *tip)  # ضلفة الباب
        sh.draw_bezier(P(*tip),
                       P(tip[0] + ux * r * KAPPA, tip[1] + uy * r * KAPPA),
                       P(latch[0] + nx * r * KAPPA, latch[1] + ny * r * KAPPA),
                       P(*latch))

    W, D, t, ti = 10.0, 7.0, 0.25, 0.15

    # --- الجدار الجنوبي: شباك 2.0→3.5 وباب مدخل 7.5→8.5
    for a, b in [(0, 2.0), (3.5, 7.5), (8.5, W)]:
        line(a, 0, b, 0)
    for a, b in [(t, 2.0), (3.5, 7.5), (8.5, W - t)]:
        line(a, t, b, t)
    for x in (2.0, 3.5, 7.5, 8.5):
        line(x, 0, x, t)  # أطراف الفتحات
    line(2.0, 0, 3.5, 0); line(2.0, t, 3.5, t)  # وجها الشباك
    line(2.0, t / 2, 3.5, t / 2)                # خط الزجاج
    door_swing(7.5, t, 1, 0, 0, 1, 1.0)          # باب المدخل يفتح للداخل

    # --- بقية الجدار الخارجي
    line(0, D, W, D);  line(t, D - t, W - t, D - t)  # شمالي
    line(0, 0, 0, D);  line(t, t, t, D - t)          # غربي
    line(W, 0, W, D);  line(W - t, t, W - t, D - t)  # شرقي

    # --- جدار داخلي عند x=6 بسماكة 15 سم مع باب 3.0→3.9
    xi = 6.0
    line(xi, t, xi, 3.0);      line(xi + ti, t, xi + ti, 3.0)
    line(xi, 3.9, xi, D - t);  line(xi + ti, 3.9, xi + ti, D - t)
    line(xi, 3.0, xi + ti, 3.0);  line(xi, 3.9, xi + ti, 3.9)
    door_swing(xi + ti, 3.0, 0, 1, 1, 0, 0.9)    # يفتح نحو الغرفة الشرقية
    sh.finish(color=(0, 0, 0), width=0.5)

    # خط أبعاد (يجب ألا يُكتشف كجدار)
    sh.draw_line(P(0, -0.8), P(W, -0.8))
    sh.finish(color=(0.4, 0.4, 0.4), width=0.2)
    sh.commit()

    out = Path(__file__).parent / "sample_plan.pdf"
    doc.save(out)
    print("تم إنشاء:", out)


if __name__ == "__main__":
    main()
