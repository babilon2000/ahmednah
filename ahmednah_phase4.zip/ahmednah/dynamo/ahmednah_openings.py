# -*- coding: utf-8 -*-
"""
ahmednah - Dynamo Python Script (المرحلة الثالثة): الأبواب والشبابيك
====================================================================
يُلصق داخل عقدة Python Script ثانية، تأتي بعد Wall.ByCurveAndHeight.

المدخلات:
    IN[0]  الجدران الناتجة من Wall.ByCurveAndHeight
    IN[1]  مسار ملف Excel (نفس ملف المرحلة 2 — ورقة Openings)
    IN[2]  نوع الباب (اختياري) مثل "Single-Flush" أو "Single-Flush : 0915 x 2134mm"
    IN[3]  نوع الشباك (اختياري) مثل "Fixed"
    IN[4]  ارتفاع جلسة الشباك بالمتر (افتراضي 0.9)
    IN[5]  ارتفاع الفتحة الفارغة بالمتر (افتراضي 2.1)

العمل:
    - لكل باب/شباك: يختار FamilySymbol بنفس العرض، وإن لم يجد ينسخ نوعاً ويضبط عرضه
    - يضعه FamilyInstance مستضافاً في الجدار الصحيح (أقرب جدار للنقطة)
    - يضبط جهة فتح الباب والمفصلة كما في المخطط، ويجعل وجه الشباك للخارج
    - الفتحات بدون باب: Wall Opening مستطيلة
    - عند إعادة التشغيل يحذف ما أنشأه سابقاً (معلَّم بـ Comments = ahmednah) فلا يتكرر
"""

import clr
import re
import zipfile
import xml.etree.ElementTree as ET

clr.AddReference("RevitServices")
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

clr.AddReference("RevitAPI")
import Autodesk.Revit.DB as DB
from Autodesk.Revit.DB.Structure import StructuralType

clr.AddReference("RevitNodes")
import Revit
clr.ImportExtensions(Revit.Elements)

doc = DocumentManager.Instance.CurrentDBDocument
FT = 1.0 / 0.3048     # متر → قدم (وحدة Revit الداخلية)
TAG = "ahmednah"

# ---------------------------------------------------------------------------
# معايرة اتجاه الأبواب (مرة واحدة فقط):
# عائلات الأبواب تختلف في تعريف الوجه (Facing) واليد (Hand).
# الإعداد الافتراضي مناسب لعائلات Revit القياسية (Single-Flush):
#   الباب يفتح عكس اتجاه FacingOrientation، والمفصلة عكس اتجاه HandOrientation.
# إذا فتحت كل الأبواب للجهة الخطأ → غيّر SWING_TOWARD_FACING
# إذا كانت كل المفصلات في الطرف الخطأ → غيّر HINGE_TOWARD_HAND
# ---------------------------------------------------------------------------
SWING_TOWARD_FACING = False
HINGE_TOWARD_HAND = False


# ---------------------------------------------------------------------------
# قراءة Excel (نفس قارئ المرحلة 2 — مكتبات قياسية فقط)
# ---------------------------------------------------------------------------
NS_M = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _col_index(ref):
    letters = re.match(r"([A-Z]+)", ref).group(1)
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def read_xlsx_sheet(path, sheet_name):
    z = zipfile.ZipFile(path)
    names = z.namelist()

    shared = []
    if "xl/sharedStrings.xml" in names:
        root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in root.findall("{%s}si" % NS_M):
            shared.append("".join([t.text or "" for t in si.iter("{%s}t" % NS_M)]))

    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    relmap = dict((r.get("Id"), r.get("Target")) for r in rels)

    target = None
    for sh in wb.find("{%s}sheets" % NS_M):
        if sh.get("name") == sheet_name:
            target = relmap[sh.get("{%s}id" % NS_R)]
    if target is None:
        raise Exception("Sheet '%s' not found in Excel file" % sheet_name)
    target = target[1:] if target.startswith("/") else "xl/" + target

    sheet = ET.fromstring(z.read(target))
    rows = []
    for row in sheet.find("{%s}sheetData" % NS_M):
        cells = {}
        for c in row:
            t = c.get("t")
            if t == "inlineStr":
                v = "".join([x.text or "" for x in c.iter("{%s}t" % NS_M)])
            else:
                v_el = c.find("{%s}v" % NS_M)
                v = v_el.text if v_el is not None else None
                if v is not None:
                    if t == "s":
                        v = shared[int(v)]
                    elif t not in ("str", "b", "e"):
                        v = float(v)
            cells[_col_index(c.get("r"))] = v
        if cells:
            rows.append([cells.get(i) for i in range(max(cells) + 1)])
    z.close()
    return rows


def read_openings(path):
    rows = read_xlsx_sheet(path, "Openings")
    if len(rows) < 2:
        return []
    header = [str(h).strip() for h in rows[0]]
    out = []
    for r in rows[1:]:
        r = r + [None] * (len(header) - len(r))
        d = dict(zip(header, r))
        try:
            out.append({
                "id": int(d["Opening_ID"]), "type": str(d["Type"]),
                "x": float(d["X"]), "y": float(d["Y"]), "width": float(d["Width_m"]),
                "thk": float(d["Wall_Thickness_m"] or 0.2),
                "swing": int(float(d.get("Swing_Side") or 0)),
                "hinge": str(d.get("Hinge_At") or ""),
                "leaves": int(float(d.get("Leaves") or 1)),
            })
        except (TypeError, ValueError, KeyError):
            continue
    return out


# ---------------------------------------------------------------------------
# أدوات
# ---------------------------------------------------------------------------
def flatten(x):
    if isinstance(x, (list, tuple)):
        res = []
        for i in x:
            res.extend(flatten(i))
        return res
    return [x]


def ename(e):
    try:
        return e.Name
    except Exception:
        return e.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()


def full_name(sym):
    return "%s : %s" % (sym.FamilyName, ename(sym))


def width_param(sym):
    for bip in ("DOOR_WIDTH", "WINDOW_WIDTH", "FAMILY_WIDTH_PARAM", "FURNITURE_WIDTH"):
        try:
            p = sym.get_Parameter(getattr(DB.BuiltInParameter, bip))
        except Exception:
            p = None
        if p is not None and p.StorageType == DB.StorageType.Double:
            return p
    for n in ("Width", "width", "Rough Width"):
        p = sym.LookupParameter(n)
        if p is not None and p.StorageType == DB.StorageType.Double:
            return p
    return None


def set_comment(el, text):
    p = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
    if p is not None and not p.IsReadOnly:
        p.Set(text)


def get_comment(el):
    p = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
    return p.AsString() if p is not None else None


class SymbolPicker(object):
    """يختار (أو ينشئ) FamilySymbol بالعرض المطلوب لكل فئة."""

    def __init__(self, bic, wanted_name):
        self.all = list(DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(bic))
        self.pool = self.all
        if wanted_name:
            w = wanted_name.strip().lower()
            m = [s for s in self.all if w == full_name(s).lower() or w == ename(s).lower()
                 or w == s.FamilyName.lower()]
            if not m:
                m = [s for s in self.all if w in full_name(s).lower()]
            if not m:
                raise Exception("Family type '%s' not found. Available: %s" %
                                (wanted_name, "; ".join(sorted(set(full_name(s) for s in self.all)))))
            self.pool = m
        self.cache = {}
        self.created = []
        self.warnings = []

    def get(self, width_m, leaves=1):
        if not self.pool:
            return None
        key = (int(round(width_m * 1000)), leaves)
        if key in self.cache:
            return self.cache[key]
        pool = self.pool
        if leaves >= 2:
            dbl = [s for s in pool if "double" in s.FamilyName.lower()]
            pool = dbl or pool
        target = width_m * FT
        best = None
        for s in pool:  # أ) نوع موجود بنفس العرض (±1 سم)
            p = width_param(s)
            if p is not None and abs(p.AsDouble() - target) < 0.01 * FT:
                best = s
                break
        if best is None:  # ب) ننسخ نوعاً من نفس العائلة ونضبط عرضه
            base = pool[0]
            new_name = "%s_%s_%dmm" % (ename(base), TAG, key[0])
            existing = [s for s in self.all if ename(s) == new_name and s.FamilyName == base.FamilyName]
            if existing:
                best = existing[0]
            else:
                best = base.Duplicate(new_name)
                p = width_param(best)
                if p is not None and not p.IsReadOnly:
                    p.Set(target)
                    self.created.append(full_name(best))
                else:
                    self.warnings.append("Width not editable in '%s' — used as is" % full_name(base))
                self.all.append(best)
        if not best.IsActive:
            best.Activate()
            doc.Regenerate()
        self.cache[key] = best
        return best


def host_for(walls, pt, thk):
    """أقرب جدار للنقطة، بشرط أن تقع النقطة على امتداده."""
    best, best_d = None, None
    for w in walls:
        lc = w.Location
        if not isinstance(lc, DB.LocationCurve):
            continue
        c = lc.Curve
        res = c.Project(pt)
        if res is None:
            continue
        d = res.XYZPoint.DistanceTo(DB.XYZ(pt.X, pt.Y, res.XYZPoint.Z))
        if d < (thk / 2 + 0.05) * FT and (best_d is None or d < best_d):
            best, best_d = w, d
    return best


def wall_dir(w):
    c = w.Location.Curve
    v = c.GetEndPoint(1) - c.GetEndPoint(0)
    return DB.XYZ(v.X, v.Y, 0).Normalize()


# ---------------------------------------------------------------------------
# التنفيذ
# ---------------------------------------------------------------------------
walls = [w for w in flatten(UnwrapElement(IN[0])) if isinstance(w, DB.Wall)]
path = IN[1]
door_name = IN[2] if len(IN) > 2 and IN[2] else ""
window_name = IN[3] if len(IN) > 3 and IN[3] else ""
sill_m = float(IN[4]) if len(IN) > 4 and IN[4] is not None else 0.9
open_h_m = float(IN[5]) if len(IN) > 5 and IN[5] is not None else 2.1



def id_val(eid):  # Revit 2024+ يستخدم Value بدل IntegerValue
    return eid.Value if hasattr(eid, "Value") else eid.IntegerValue


ops = read_openings(path)
wall_ids = set(id_val(w.Id) for w in walls)

TransactionManager.Instance.EnsureInTransaction(doc)

# 1) حذف ما أنشأناه في تشغيل سابق
old = []
for bic in (DB.BuiltInCategory.OST_Doors, DB.BuiltInCategory.OST_Windows):
    for fi in DB.FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType():
        if get_comment(fi) == TAG and fi.Host is not None and id_val(fi.Host.Id) in wall_ids:
            old.append(fi.Id)
for op in DB.FilteredElementCollector(doc).OfClass(DB.Opening):
    if op.Host is not None and id_val(op.Host.Id) in wall_ids:
        old.append(op.Id)
for eid in old:
    doc.Delete(eid)

# 2) مركز المبنى (لنعرف أين "الخارج" عند توجيه الشبابيك)
mids = [w.Location.Curve.Evaluate(0.5, True) for w in walls]
cx = sum(p.X for p in mids) / max(len(mids), 1)
cy = sum(p.Y for p in mids) / max(len(mids), 1)

doors = SymbolPicker(DB.BuiltInCategory.OST_Doors, door_name)
wins = SymbolPicker(DB.BuiltInCategory.OST_Windows, window_name)

placed, errors, n_open = [], [], 0
for o in ops:
    try:
        pt = DB.XYZ(o["x"] * FT, o["y"] * FT, 0)
        wall = host_for(walls, pt, o["thk"])
        if wall is None:
            errors.append("#%d: no host wall found" % o["id"])
            continue
        level = doc.GetElement(wall.LevelId)
        z = level.Elevation
        d = wall_dir(wall)
        pt = DB.XYZ(pt.X, pt.Y, z)

        if o["type"] == "Opening":
            half = d.Multiply(o["width"] * FT / 2)
            doc.Create.NewOpening(wall, pt.Subtract(half), pt.Add(half).Add(DB.XYZ(0, 0, open_h_m * FT)))
            n_open += 1
            continue

        picker = doors if o["type"] == "Door" else wins
        sym = picker.get(o["width"], o["leaves"])
        if sym is None:
            errors.append("#%d: no %s family loaded in project" % (o["id"], o["type"]))
            continue
        inst = doc.Create.NewFamilyInstance(pt, sym, wall, level, StructuralType.NonStructural)
        set_comment(inst, TAG)
        if o["type"] == "Window":
            p = inst.get_Parameter(DB.BuiltInParameter.INSTANCE_SILL_HEIGHT_PARAM)
            if p is not None and not p.IsReadOnly:
                p.Set(sill_m * FT)
        placed.append((inst, o, d))
    except Exception as ex:
        errors.append("#%d: %s" % (o["id"], ex))

# 3) ضبط الاتجاهات (يحتاج Regenerate حتى تُحسب Facing/Hand)
doc.Regenerate()
left = lambda v: DB.XYZ(-v.Y, v.X, 0)
for inst, o, d in placed:
    try:
        facing = inst.FacingOrientation
        if o["type"] == "Door" and o["swing"] != 0:
            swing = left(d).Multiply(o["swing"])
            want = 1 if SWING_TOWARD_FACING else -1
            if facing.DotProduct(swing) * want < 0:
                inst.flipFacing()
            if o["hinge"] in ("start", "end"):
                doc.Regenerate()
                hinge = d.Negate() if o["hinge"] == "start" else d
                want = 1 if HINGE_TOWARD_HAND else -1
                if inst.HandOrientation.DotProduct(hinge) * want < 0:
                    inst.flipHand()
        elif o["type"] == "Window":
            p = inst.Location.Point
            outward = DB.XYZ(p.X - cx, p.Y - cy, 0)
            n = left(d)
            out_n = n if n.DotProduct(outward) > 0 else n.Negate()
            if facing.DotProduct(out_n) < 0:
                inst.flipFacing()
    except Exception as ex:
        errors.append("#%d orient: %s" % (o["id"], ex))

TransactionManager.Instance.TransactionTaskDone()

n_d = sum(1 for _, o, _ in placed if o["type"] == "Door")
n_w = sum(1 for _, o, _ in placed if o["type"] == "Window")
report = [
    "ahmednah - openings in Excel: %d" % len(ops),
    "Doors placed: %d | Windows placed: %d | Empty openings: %d" % (n_d, n_w, n_open),
    "Removed from previous run: %d" % len(old),
    "Door types: %s" % (", ".join(sorted(set(full_name(s) for s in doors.cache.values()))) or "-"),
    "Window types: %s" % (", ".join(sorted(set(full_name(s) for s in wins.cache.values()))) or "-"),
    "Types created: %s" % (", ".join(doors.created + wins.created) or "none"),
]
report += doors.warnings + wins.warnings
if errors:
    report.append("ERRORS:")
    report += errors

OUT = [[i.ToDSType(True) for i, _, _ in placed], "\n".join(report)]
